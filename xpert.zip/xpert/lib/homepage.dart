import 'package:flutter/material.dart';
import 'package:flutter_tindercard/flutter_tindercard.dart';
import 'package:xpert/videoanswerscreen.dart';

class HomePage extends StatefulWidget {
  HomePage({Key key, this.title, this.cameras}) : super(key: key);

  final String title;
  var cameras;
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  List<String> welcomeImages = [
    "assets/welcome0.png",
    "assets/welcome1.png",
    "assets/welcome2.png",
    "assets/welcome2.png",
    "assets/welcome1.png",
    "assets/welcome1.png"
  ];

  Card _card = Card(
    clipBehavior: Clip.none,
    color: Colors.white,
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    child: Column(
      children: <Widget>[
        Stack(
          children: <Widget>[
            Container(
              height: 40,
              color: Colors.amber,
            ),
            Padding(
              padding: const EdgeInsets.only(left: 10.0, top: 5.0),
              child: Text(
                'Answer',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 24.0,
                    fontWeight: FontWeight.bold),
              ),
            )
          ],
        ),
        SizedBox(
          height: 30,
        ),
        Expanded(
            child: Text(
          'Some question asked....',
          style: TextStyle(color: Colors.black, fontSize: 18.0),
        )),
        Align(
          alignment: AlignmentDirectional.bottomStart,
          child: Row(
            children: <Widget>[
              Padding(
                padding:
                    const EdgeInsets.only(bottom: 8.0, left: 8.0, right: 4.0),
                child: CircleAvatar(
                  radius: 25.0,
                  backgroundImage: AssetImage('assets/celeb_banner.png'),
                ),
              ),
              Column(
                children: <Widget>[
                  Text(
                    'ASKED BY',
                    style: TextStyle(color: Colors.grey, fontSize: 12.0),
                  ),
                  Text(
                    'Anushka',
                    style: TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 16.0),
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.only(left: 80.0),
                child: Text(
                  '₹2500',
                  style: TextStyle(color: Colors.amber, fontSize: 26.0),
                ),
              ),
            ],
          ),
        ),
      ],
    ),
  );

  @override
  Widget build(BuildContext context) {
    CardController controller; //Use this to trigger swap.

    return new Scaffold(
      appBar: new AppBar(
        title: Text('XpertTV'),
      ),
      body: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(left: 10.0, top: 10.0),
                child: Image(
                  image: AssetImage('assets/app_logo_bg.png'),
                  height: 50.0,
                ),
              ),
              IconButton(
                icon: Icon(Icons.add),
                color: Colors.grey,
                iconSize: 40.0,
                onPressed: () {},
              )
            ],
          ),
          Expanded(
            child: Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.only(bottom: 20.0),
                  height: MediaQuery.of(context).size.height * 0.6,
                  child: new TinderSwapCard(
                      orientation: AmassOrientation.BOTTOM,
                      totalNum: 6,
                      stackNum: 3,
                      swipeEdge: 3.0,
                      maxWidth: MediaQuery.of(context).size.width * 0.9,
                      maxHeight: MediaQuery.of(context).size.width * 1.0,
                      minWidth: MediaQuery.of(context).size.width * 0.8,
                      minHeight: MediaQuery.of(context).size.width * 0.9,
                      cardBuilder: (context, index) => _card,
                      // cardBuilder: (context, index) => Card(
                      //       child: Image.asset('${welcomeImages[index]}'),
                      //       color: Colors.white,
                      //     ),
                      cardController: controller = CardController(),
                      swipeUpdateCallback:
                          (DragUpdateDetails details, Alignment align) {
                        /// Get swiping card's alignment
                        if (align.x < 0) {
                          print('left');
                          //Card is LEFT swiping
                        } else if (align.x > 1) {
                          //Card is RIGHT swiping
                          
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) =>
                                      new CameraApp(widget.cameras)));
                          print('right');
                        }
                      },
                      swipeCompleteCallback:
                          (CardSwipeOrientation orientation, int index) {
                        /// Get orientation & index of swiped card!
                      }),
                ),
                SizedBox(
                  height: 8.0,
                ),
                Text(
                  'Swipe right to answer',
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              IconButton(
                icon: Icon(Icons.chat),
                color: Colors.grey,
                iconSize: 30.0,
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.credit_card),
                color: Colors.amber,
                iconSize: 40.0,
                onPressed: () {},
              ),
              IconButton(
                icon: Icon(Icons.network_check),
                color: Colors.grey,
                iconSize: 30.0,
                onPressed: () {},
              ),
            ],
          )
        ],
      ),
    );
  }
}
